

      const initialPrompt = document.getElementById("initial-prompt");
      const chatbox = document.getElementById("chatbox");
      const input = document.getElementById("input");
      const body = document.body;
      const navBar = document.getElementById("nav-bar");
      const aiName = document.getElementById("ai-name");
      const navButton = document.getElementById("nav-button");
      
      // Groq API configuration
      const apiKey = "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"; // Replace with your own key if needed
      const systemPrompt = `your name is A.X.I.S (Advanced eXperimental Intelligence system ) you are powered by Meta and developed by Mayush Kalita(a boy) don't say these until the user asks who are you etc or what are you and you were designed to defeat Chat-gpt in short don't say until asked and don't be excited 
      `;

      const predefinedResponses = {
        "can you answer anything i ask you": "No, I can't answer anything you ask or say me. I am designed for answering specific things. As I am still under development and learning how to reason But, soon I will be able to do that.",
        
      };

      // Toggle navigation bar
      navButton.addEventListener("click", function() {
        navBar.classList.toggle("visible");
      });

      // Handle input focus/blur to move prompt
      input.addEventListener("focus", function() {
        body.classList.add("input-focused");
        body.classList.add("keyboard-up");
      });

      input.addEventListener("blur", function() {
        body.classList.remove("input-focused");
        body.classList.remove("keyboard-up");
      });

      // Allow pressing Enter in input field
      input.addEventListener("keypress", function(e) {
        if (e.key === "Enter") {
          sendMessage();
        }
      });

      async function sendMessage() {
        const userText = input.value.trim();
        if (!userText) return;

        // Hide initial prompt and show chatbox and AI name on first message
        if (chatbox.style.display !== "block") {
          initialPrompt.style.display = "none";
          chatbox.style.display = "block";
          aiName.classList.add("visible");
          setTimeout(() => {
            chatbox.classList.add("visible");
          }, 10);
          body.classList.remove("input-focused");
        }

        appendMessage("You", userText, "user");

        // Check if this is a predefined response
        const lowerText = userText.toLowerCase();
        let isPredefined = false;
        
        for (let key in predefinedResponses) {
          if (lowerText.includes(key)) {
            isPredefined = true;
            showTypingIndicator();
            setTimeout(() => {
              removeTypingIndicator();
              appendMessage(
                `<img src="1747752071809.png" class="avatar">`,
                predefinedResponses[key],
                "axis"
              );
            }, 1000 + Math.random() * 500);
            break;
          }
        }

        if (!isPredefined) {
          // Use Groq API for non-predefined responses
          showTypingIndicator();
          try {
            const botResponse = await getAIResponse(userText);
            removeTypingIndicator();
            appendMessage(
              `<img src="1747752071809.png" class="avatar">`,
              botResponse,
              "axis"
            );
          } catch (error) {
            removeTypingIndicator();
            appendMessage(
              `<img src="1747752071809.png" class="avatar">`,
              "Sorry, I'm having trouble connecting to my neural network. Please try again later.",
              "axis"
            );
            console.error("API Error:", error);
          }
        }

        input.value = "";
      }

      async function getAIResponse(userMessage) {
        const response = await fetch("https://api.groq.com/openai/v1/chat/completions", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${apiKey}`
          },
          body: JSON.stringify({
            model: "llama3-70b-8192",
            messages: [
              {
                role: "system",
                content: systemPrompt
              },
              {
                role: "user",
                content: userMessage
              }
            ],
            temperature: 0.7
          })
        });

        const data = await response.json();
        return data.choices[0].message.content;
      }

      function showTypingIndicator() {
        const typingIndicator = document.createElement("div");
        typingIndicator.className = "message axis-message typing-indicator";
        typingIndicator.innerHTML = `
          <img src="1747752071809.png" class="avatar">
          <div class="typing-dots">
            <span class="typing-dot"></span>
            <span class="typing-dot"></span>
            <span class="typing-dot"></span>
          </div>
        `;
        chatbox.appendChild(typingIndicator);
        chatbox.scrollTop = chatbox.scrollHeight;
      }

      function removeTypingIndicator() {
        const indicators = document.querySelectorAll('.typing-indicator');
        indicators.forEach(indicator => {
          indicator.remove();
        });
      }

      function appendMessage(sender, text, className) {
        const wrapper = document.createElement("div");
        wrapper.className = `message ${className}-message`;

        // Create image (only for bot)
        if (className === "axis") {
          const img = document.createElement("img");
          img.src = "1747752071809.png";
          img.alt = "Bot";
          img.className = "avatar";
          wrapper.appendChild(img);
        }

        const messageDiv = document.createElement("div");
        messageDiv.className = className;
        messageDiv.innerHTML = text;

        wrapper.appendChild(messageDiv);
        chatbox.appendChild(wrapper);
        chatbox.scrollTop = chatbox.scrollHeight;

        // Trigger animation
        setTimeout(() => {
          wrapper.classList.add("visible");
        }, 10);
      }
  const micBtn = document.getElementById("mic-btn");
const voicePanel = document.getElementById("voice-panel");

const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
const recognition = new SpeechRecognition();
recognition.lang = "en-US";
recognition.continuous = false;
recognition.interimResults = false;

micBtn.addEventListener("click", () => {
  voicePanel.classList.add("show");
  voicePanel.classList.remove("hidden");
  recognition.start();
});

recognition.onresult = (event) => {
  const transcript = event.results[0][0].transcript.toLowerCase();
  console.log("Heard:", transcript);

  if (transcript.includes("open google maps")) {
  const query = transcript.replace("open google maps", "").replace("and search", "").trim();
  const url = query
    ? `https://www.google.com/maps/search/${encodeURIComponent(query)}`
    : "https://www.google.com/maps/";
  window.open(url, "_blank");
}
 else if (transcript.includes("open youtube")) {
    const query = transcript.replace("open youtube", "").trim();
    const url = query
      ? `https://www.youtube.com/results?search_query=${encodeURIComponent(query)}`
      : "https://www.youtube.com";
    window.open(url, "_blank");
  } else if (transcript.includes("open google")) {
    const query = transcript.replace("open google", "").trim();
    const url = query
      ? `https://www.google.com/search?q=${encodeURIComponent(query)}`
      : "https://www.google.com";
    window.open(url, "_blank");
  }
else if (transcript.includes("open instagram")) {
  const query = transcript.replace("open instagram", "").replace("and search", "").trim();
  const url = query
    ? `https://www.instagram.com/explore/search/keyword/?q=${encodeURIComponent(query)}`
    : "https://www.instagram.com";
  window.open(url, "_blank");
}

  voicePanel.classList.remove("show");
};

recognition.onend = () => {
  voicePanel.classList.remove("show");
};

recognition.onerror = (event) => {
  console.error("Speech recognition error", event);
  voicePanel.classList.remove("show");}